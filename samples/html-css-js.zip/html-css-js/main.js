// dummy js to verify this file is being used
alert('js file main.js is loaded');
